async function calculate() {
  const algorithm = document.getElementById('algorithm').value;
  const requests = document.getElementById('requests').value;
  const head = document.getElementById('head').value;
  const direction = document.getElementById('direction').value;

  const response = await fetch('/calculate', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ algorithm, requests, head, direction })
  });

  const data = await response.json();
  if (data.error) {
    document.getElementById('result').innerText = data.error;
    return;
  }

  document.getElementById('result').innerHTML = `
    Sequence: [${data.sequence.join(', ')}]<br>
    Total Seek Time: ${data.total_seek}<br>
    Average Seek Time: ${data.average_seek}
  `;

  const ctx = document.getElementById('chart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: [head, ...data.sequence],
      datasets: [{
        label: `${algorithm} Head Movement`,
        data: [head, ...data.sequence],
        borderColor: '#3498db',
        fill: false,
        tension: 0.3
      }]
    },
    options: { responsive: true }
  });
}
