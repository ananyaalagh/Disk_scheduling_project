let chartInstance = null;

async function calculate() {

  console.log("Calculate button clicked"); // debug

  const algorithm = document.getElementById('algorithm').value;
  const requests = document.getElementById('requests').value;
  const head = Number(document.getElementById('head').value);
  const direction = document.getElementById('direction').value;

  const response = await fetch('/calculate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ algorithm, requests, head, direction })
  });

  const data = await response.json();
  console.log("Backend returned:", data); // debug

  if (data.error) {
    document.getElementById('result').innerText = data.error;
    return;
  }

  document.getElementById('result').innerHTML = `
    <br><b>Sequence:</b> [${data.sequence.join(', ')}]
    <br><b>Total Seek Time:</b> ${data.total_seek}
    <br><b>Average Seek Time:</b> ${data.average_seek}
  `;

  const chartCanvas = document.getElementById('chart');
  console.log("Canvas element:", chartCanvas); // debug

  if (!chartCanvas) {
    console.log("ERROR: Canvas #chart not found!");
    return;
  }

  const ctx = chartCanvas.getContext('2d');

  if (!ctx) {
    console.log("ERROR: ctx is NULL — chart cannot draw");
    return;
  }

  // destroy old chart
  if (chartInstance) {
    chartInstance.destroy();
  }

  console.log("Drawing chart..."); // debug

  chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: [head, ...data.sequence],
      datasets: [{
        label: `${algorithm} Head Movement`,
        data: [head, ...data.sequence],
        borderColor: '#3498db',
        borderWidth: 2,
        pointRadius: 4,
        fill: false,
        tension: 0.3
      }]
    },
    options: {
      responsive: true
    }
  });

  console.log("Chart drawn successfully!"); // debug
}
