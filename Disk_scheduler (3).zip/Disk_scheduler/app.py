from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


def fcfs(requests, head):
    seq, total = [], 0
    for r in requests:
        seq.append(r)
        total += abs(head - r)
        head = r
    return seq, total

def sstf(requests, head):
    seq, total = [], 0
    reqs = requests[:]
    while reqs:
        closest = min(reqs, key=lambda x: abs(head - x))
        total += abs(head - closest)
        seq.append(closest)
        head = closest
        reqs.remove(closest)
    return seq, total

def scan(requests, head, direction, disk_size=200):
    seq, total = [], 0
    left = [r for r in requests if r < head]
    right = [r for r in requests if r > head]
    left.sort()
    right.sort()

    if direction == "left":
        for r in reversed(left):
            seq.append(r)
            total += abs(head - r)
            head = r
        if right:
            total += head
            head = 0
            for r in right:
                seq.append(r)
                total += abs(head - r)
                head = r
    else:
        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r
        if left:
            total += (disk_size - head - 1)
            head = disk_size - 1
            for r in reversed(left):
                seq.append(r)
                total += abs(head - r)
                head = r

    return seq, total

def look(requests, head, direction):
    seq, total = [], 0
    left = sorted([r for r in requests if r < head])
    right = sorted([r for r in requests if r > head])

    if direction == "left":
        for r in reversed(left):
            seq.append(r)
            total += abs(head - r)
            head = r
        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r
    else:
        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r
        for r in reversed(left):
            seq.append(r)
            total += abs(head - r)
            head = r

    return seq, total


def cscan(requests, head, direction, disk_size=200):
    seq, total = [], 0
    left = sorted([r for r in requests if r < head])
    right = sorted([r for r in requests if r > head])

    if direction == "right":
        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r

        if left:
            total += (disk_size - head - 1)
            head = 0

        for r in left:
            seq.append(r)
            total += abs(head - r)
            head = r

    else:  # left direction
        for r in reversed(left):
            seq.append(r)
            total += abs(head - r)
            head = r

        if right:
            total += head
            head = disk_size - 1

        for r in reversed(right):
            seq.append(r)
            total += abs(head - r)
            head = r

    return seq, total


def clook(requests, head, direction):
    seq, total = [], 0
    left = sorted([r for r in requests if r < head])
    right = sorted([r for r in requests if r > head])

    if direction == "right":
        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r

        if left:
            total += abs(head - left[0])
            head = left[0]

        for r in left:
            seq.append(r)
            total += abs(head - r)
            head = r

    else:  
        for r in reversed(left):
            seq.append(r)
            total += abs(head - r)
            head = r

        if right:
            total += abs(head - right[0])
            head = right[0]

        for r in right:
            seq.append(r)
            total += abs(head - r)
            head = r

    return seq, total



@app.route('/')
def index():
    return render_template('index.html')


@app.route('/calculate', methods=['POST'])
def calculate():
    data = request.json
    algo = data['algorithm']
    requests = list(map(int, data['requests'].split(',')))
    head = int(data['head'])
    direction = data.get('direction', 'right')

    if algo == 'FCFS':
        seq, total = fcfs(requests, head)
    elif algo == 'SSTF':
        seq, total = sstf(requests, head)
    elif algo == 'SCAN':
        seq, total = scan(requests, head, direction)
    elif algo == 'LOOK':
        seq, total = look(requests, head, direction)
    elif algo == 'C-SCAN':
        seq, total = cscan(requests, head, direction)
    elif algo == 'C-LOOK':
        seq, total = clook(requests, head, direction)
    else:
        return jsonify({'error': 'Invalid algorithm'})

    avg = total / len(requests)
    return jsonify({
        'sequence': seq,
        'total_seek': total,
        'average_seek': round(avg, 2)
    })
